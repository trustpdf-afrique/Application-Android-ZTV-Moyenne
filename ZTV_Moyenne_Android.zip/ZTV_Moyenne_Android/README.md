# ZTV Moyenne — application Android

Cette application Android ouvre le site :
https://trustpdf-afrique.github.io/Bonne-application-de-calcul-moyenne-/

Nom : ZTV Moyenne
Package : com.ztvmoyenne.app

## Construire gratuitement

Le dossier contient un workflow GitHub Actions (`.github/workflows/build-apk.yml`).
Il construit automatiquement un APK debug lorsque le projet est placé dans un dépôt GitHub public.

Le site reste hébergé sur GitHub Pages. L'application ne contient pas le site en local : elle le charge via Internet.

## Important

Un APK debug peut être installé directement sur Android après téléchargement et autorisation d'installation depuis cette source.
La publication sur Google Play est une étape séparée et peut nécessiter un compte développeur payant.
